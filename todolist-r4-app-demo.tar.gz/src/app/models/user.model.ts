export interface UserDetails {
  id: string;
  username: string;
  firstName?: string;
  lastName?: string;
}
